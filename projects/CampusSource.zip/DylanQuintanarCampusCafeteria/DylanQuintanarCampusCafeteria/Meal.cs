﻿//Dylan Quintanar 9:00
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DylanQuintanarCampusCafeteria
{
    class Meal
    {
        //variables
        private static string mealType = "";
        private static double mealPrice = 0;
        private static int mealQuantity = 0;
        private static int[] remainingMeals = {10,20,35};
        private static  double salesTax = .1;
        private static double subtotal = 0;
        private static double total = 0;

        //methods
        public static string GetMealType()
        {
            return mealType;
        }

        public static void SetMealType(string newMealType)
        {
            mealType = newMealType;
        }


        public static double GetMealPrice()
        {
            return mealPrice;
        }


        public static void SetMealPrice(string type)
        {
            switch (type)
            {
                //set price for breakfast
                case "1":
                    mealPrice = 6.25;
                    break;
                //set price for lunch
                case "2":
                    mealPrice = 7.95;
                    break;
                //set price for dinner
                case "3":
                    mealPrice = 9.80;
                    break;
            }
        }

        public static int GetMealQuantity()
        {
            return mealQuantity;
        }

        public static void SetMealQuantity(int newMealQuantity)
        {
            mealQuantity = newMealQuantity;
        }

        public static int GetRemainingMeals(string type)
        {
            return remainingMeals[Convert.ToInt32(type) - 1];
        }

        public static int GetRemainingMeals(int type)
        {
            return remainingMeals[type];
        }

        public static void SetRemainingMeals(string mealType, int mealsRemaining)
        {
            remainingMeals[Convert.ToInt32(mealType) - 1] = mealsRemaining;
        }

        public static bool VerifyRemainingMeals(string mealType, int mealsSelected)
        {
            bool mealsVerified = false;

            if (mealsSelected <= GetRemainingMeals(mealType))
            {
                mealsVerified = true;
            }

            else
            {
                Console.WriteLine("Error: kitchen does not have enough meals remaining");
            }

            return mealsVerified;
        }

        public static double GetSubtotal()
        {
            return subtotal;
        }

        public static void SetSubTotal()
        {
            subtotal = mealPrice * mealQuantity;
        }

        public static double GetTotal()
        {
            return total;
        }

        public static void SetTotal()
        {
            total = (subtotal * salesTax) + subtotal;
        }

        public static double GetTax()
        {
            double tax = subtotal * salesTax;
            return tax;
        }

    }

    
}
