﻿//Dylan Quintanar 9:00
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DylanQuintanarCampusCafeteria
{
    class Customer
    {
        //variables
        private string firstName = "";
        private string lastName = "";
        private string collegeName = "";
        private string state = "";
        private double gpa = 0;
        private int code = 0;
        private int credits = 0;
        private double balance = 0;
        
        //constructor
        public Customer()
        {

        }

        public Customer(string fName, string lName, string school, string state, double gpa, int code, int credits, double balance)
        {
            SetFirstName(fName);
            SetLastName(lName);
            SetCollege(school);
            SetState(state);
            SetGpa(gpa);
            SetCode(code);
            SetCredits(credits);
            SetBalance(balance);
        }

        //methods
        public string GetFirstName()
        {
            return firstName;
        }

        public void SetFirstName(string name)
        {
            firstName = name;
        }

        public string GetLastName()
        {
            return lastName;
        }

        public void SetLastName(string name)
        {
            lastName = name;
        }

        public string GetCollege()
        {
            return collegeName;
        }

        public void SetCollege(string school)
        {
            collegeName = school;
        }

        public string GetState()
        {
            return state;
        }

        public void SetState(string st)
        {
            state = st;
        }

        public double GetGPA()
        {
            return gpa;
        }

        public void SetGpa(double grade)
        {
            gpa = grade;
        }

        public int GetCode()
        {
            return code;
        }

        public void SetCode(int cd)
        {
            code = cd;
        }

        public int GetCredits()
        {
            return credits;
        }

        public void SetCredits(int crdts)
        {
            credits = crdts;
        }

        public bool VerifyCredits(int mealQty)
        {
            bool isVerified = false;

            if (GetCredits() >= mealQty)
            {
                isVerified = true;
            }

            else
            {
                Console.Write("Error: not enough remaining credits to cover quantity of meals selected\nPress any key to continue");
                Console.ReadKey();
            }

            return isVerified;
        }

        public double GetBalance()
        {
            return balance;
        }

        public void SetBalance(double blnc)
        {
            balance = blnc;
        }

        public bool VerifyCard(double totalCost)
        {
            bool isVerified = false;

            if (GetBalance() >= totalCost)
            {
                isVerified = true;
            }
            else
            {
                Console.WriteLine("Error: account balance does not cover total cost\nPress any key to continue");
                Console.ReadKey();
            }

            return isVerified;
        }

        public void GetCustomerInfo()
        {
            Console.WriteLine("Name: {0} {1}", GetFirstName(), GetLastName());
            Console.WriteLine("School: " + GetCollege());
            Console.WriteLine("State: " + GetState());
            Console.WriteLine("GPA: {0}",  GetGPA().ToString("N"));
            Console.WriteLine("Code: " + GetCode());
            Console.WriteLine("Credits: {0}", GetCredits());
            Console.WriteLine("Balance: {0}", GetBalance().ToString("C"));
        }

        public bool VerifyInitialsAndCode(string initials, int code)
        {
            bool verified = false;
            string firstName = GetFirstName();
            string lastName = GetLastName();
            int userCode = GetCode();
            initials = initials.ToUpper();

            if (initials != "" && initials.Length != 1 && initials[0] == firstName[0] && initials[1] == lastName[0] && code == userCode)
            {
                verified = true;
            }

            return verified;
        }


    }
}
