﻿//Dylan Quintanar 9:00
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DylanQuintanarCampusCafeteria
{
    class Menu
    {
        public static void Main(string[] args)
        {
            //declare variables
            bool quit = false;
            bool mealSelected = true;
            bool quantitySelected = false;
            string entry = "";
            string userInitials = "";
            int userCode = 0;
            int customerNum = 0;
            bool userVerified = false;
            bool paymentChosen = false;
            bool honorsMealUsed = false;
            int oldCredits = 0;
            double oldBalance = 0;
            string mealType = "";
            bool usedCredits = false;
            bool usedCard = false;

            Customer[] student = {
                                     new Customer("Guest", "", "", "", 0, 0, 0, 0),
                                     new Customer("Dylan", "Quintanar", "ASU", "AZ", 3.8, 10, 5, 30.99),
                                     new Customer("Iron", "Man", "Oregon", "OR", 3.00, 44, 1, 1289.62),
                                     new Customer("Steve", "Nash", "SCU", "CA", 3.49, 55, 100, 4.25)
                                 };
       
            do
            {
                Console.Clear();
                customerNum = 0;

                //display menu and set meal type             
                do 
                {
                    mealSelected = true;
                    Console.Clear();
                    
                    Menu.DisplayMenu();
                    mealType = Console.ReadLine();
                    switch (mealType)
                    {
                        case "1":
                            Meal.SetMealPrice(mealType);
                            Meal.SetMealType("Breakfast");
                            break;
                        case "2":
                            Meal.SetMealPrice(mealType);
                            Meal.SetMealType("Lunch");
                            break;
                        case "3":
                            Meal.SetMealPrice(mealType);
                            Meal.SetMealType("Dinner");
                            break;
                        case "4":
                            quit = true;
                            break;
                        default:
                            Console.WriteLine();
                            Console.Write("Error: enter a number from 1-3...press any key to try again: ");
                            Console.ReadKey();
                            mealSelected = false;
                            break;
                    }
                } while (!mealSelected);

                if (quit) break;

                //get meal quantity from user
                quantitySelected = false;
                do
                {
                    Console.Clear();
                    Meal.SetMealQuantity(ConvertStringToPositiveInt(GetUserInput("How many meals would you like to purchase?")));
                    if (Meal.GetMealQuantity() == 0)
                    {
                        Console.Write("Error: enter a number greater than 0...press any key to try again: ");
                        Console.ReadKey();
                    }
                    else
                    {
                        quantitySelected = true;
                    }
                } while (!quantitySelected);

                //display subtotal
                Console.Clear();
                Meal.SetSubTotal();
                Meal.SetTotal();
                Console.WriteLine("Meal: " + Meal.GetMealType());
                Console.WriteLine("Quantity: {0}", Meal.GetMealQuantity());
                Console.WriteLine("Price: {0}", Meal.GetMealPrice().ToString("C"));
                Console.WriteLine("Subtotal: {0}", Meal.GetSubtotal().ToString("C"));
                Console.WriteLine();


                //verify student account
                entry = GetUserInput("Press g to continue as guest, any other key to verify student account").ToUpper();

                if(entry != "G")
                {
                    do
                    {
                        Console.Clear();
                        userVerified = false;
                        userInitials = GetUserInput("Enter your initials");
                        userCode = ConvertStringToInt(GetUserInput("Enter your code"));
                        
                        for (int i = 1; i < student.Length; i++)
                        {
                            if (student[i].VerifyInitialsAndCode(userInitials, userCode))
                            {
                                customerNum = i;
                                userVerified = true;
                            }
                        }

                        if (!userVerified)
                        {
                            Console.WriteLine();
                            entry = GetUserInput("Error: invalid initials and/or code \nTo continue as a guest press g, any other key to try again").ToUpper();
                            if (entry == "G")
                            {
                                customerNum = 0;
                                userVerified = true;
                            }
                        }
                    } while (!userVerified);
                }

                //user payment
                oldBalance = student[customerNum].GetBalance();
                oldCredits = student[customerNum].GetCredits();
                paymentChosen = false;
                usedCredits = false;
                usedCard = false;
                do 
                {
                    Console.Clear();
                    Console.WriteLine("Welcome {0} {1}!", student[customerNum].GetFirstName(), student[customerNum].GetLastName());
                    Console.WriteLine();
                    entry = GetPaymentChoice();

                    switch (entry)
                    {
                        case "1":
                            //verify meal credits
                            Console.WriteLine();
                            if (student[customerNum].VerifyCredits(Meal.GetMealQuantity()))
                            {
                                if(!Meal.VerifyRemainingMeals(mealType, Meal.GetMealQuantity()))
                                {
                                    entry = GetUserInput("Press q to enter a new meal quantity, any other key to return to menu").ToUpper();
                                    if (entry == "Q")
                                    {
                                        Console.WriteLine();
                                        quantitySelected = false;
                                        do
                                        {
                                            Console.Clear();
                                            Meal.SetMealQuantity(ConvertStringToPositiveInt(GetUserInput("How many meals would you like to purchase?")));
                                            if (Meal.GetMealQuantity() == 0)
                                            {
                                                Console.Write("Error: enter a number greater than 0...press any key to try again: ");
                                                Console.ReadKey();
                                            }
                                            else
                                            {
                                                quantitySelected = true;
                                            }
                                        } while (!quantitySelected);
                                    }
                                }
                                else
                                {
                                    paymentChosen = true;
                                    usedCredits = true;
                                    //update credits and meals remaining
                                    student[customerNum].SetCredits(student[customerNum].GetCredits() - Meal.GetMealQuantity());
                                    Meal.SetRemainingMeals(mealType, Meal.GetRemainingMeals(mealType) - Meal.GetMealQuantity());
                                }
                            }
                            break;
                        case "2":
                            //verify card
                            Console.WriteLine();
                            if (student[customerNum].VerifyCard(Meal.GetTotal()))
                            {
                                if (!Meal.VerifyRemainingMeals(mealType, Meal.GetMealQuantity()))
                                {
                                    entry = GetUserInput("Press q to enter a new meal quantity, any other key to return to menu").ToUpper();
                                    if (entry == "Q")
                                    {
                                        Console.WriteLine();
                                        quantitySelected = false;
                                        do
                                        {
                                            Console.Clear();
                                            Meal.SetMealQuantity(ConvertStringToPositiveInt(GetUserInput("How many meals would you like to purchase?")));
                                            if (Meal.GetMealQuantity() == 0)
                                            {
                                                Console.Write("Error: enter a number greater than 0...press any key to try again: ");
                                                Console.ReadKey();
                                            }
                                            else
                                            {
                                                quantitySelected = true;
                                            }
                                        } while (!quantitySelected);
                                    }
                                }
                                else
                                {
                                    paymentChosen = true;
                                    usedCard = true;
                                    //update credits and meals remaining
                                    student[customerNum].SetBalance(student[customerNum].GetBalance() - Meal.GetTotal());
                                    Meal.SetRemainingMeals(mealType, Meal.GetRemainingMeals(mealType) - Meal.GetMealQuantity());
                                }
                            }
                            break;
                        case "3":
                            Console.WriteLine();
                            student[customerNum].GetCustomerInfo();
                            Console.WriteLine();
                            Console.WriteLine("Press any key to continue...");
                            Console.ReadKey();
                            break;
                        case "4":
                            paymentChosen = true;
                            break;
                        default:
                            Console.WriteLine("Error: enter a number from 1-4...press any key to try again");
                            Console.ReadKey();
                            break;
                    }
                } while (!paymentChosen);

                //display receipt
                if (usedCard || usedCredits)
                {
                    Console.WriteLine("Payment Succesful! Press any key to view receipt");
                    Console.ReadKey();
                    Console.Clear();
                    
                    //check honors status
                    if (!honorsMealUsed && student[customerNum].GetGPA() > 3.5 && Meal.GetMealQuantity() > 0)
                    {
                        honorsMealUsed = true;
                        Meal.SetMealQuantity(Meal.GetMealQuantity() - 1);
                        Meal.SetTotal();
                        if (usedCredits) student[customerNum].SetCredits(student[customerNum].GetCredits() + 1);
                        if (usedCard) student[customerNum].SetBalance(oldBalance - Meal.GetTotal());
                        
                        Console.WriteLine("Congratulations! You have been awarded a free meal for maintaining honors status");
                        Console.WriteLine("Meal quantity paid for has been reduced by 1 to {0}", Meal.GetMealQuantity());
                        Console.WriteLine();
                    }

                    Meal.SetSubTotal();
                    Meal.SetTotal();
                    Console.WriteLine("                     Receipt");
                    Console.WriteLine();
                    Console.WriteLine("Old Meal Credits: {0}          Old Balance: {1}", oldCredits, oldBalance.ToString("C"));
                    Console.WriteLine("Meal type: {0}", Meal.GetMealType());
                    Console.WriteLine("QTY: {0}", Meal.GetMealQuantity());
                    Console.WriteLine("                                   Price: {0}", Meal.GetSubtotal().ToString("C"));
                    if (usedCard)
                    {
                        Console.WriteLine("                               Sales Tax: {0}", Meal.GetTax().ToString("C"));
                        Console.WriteLine("Meals Remaining: {0}           Total Cost: {1}", Meal.GetRemainingMeals(mealType), Meal.GetTotal().ToString("C"));
                    }
                    Console.WriteLine("Remaining Meal Credits: {0}        Balance: {1}", student[customerNum].GetCredits(), student[customerNum].GetBalance().ToString("C"));
                }

                Console.WriteLine();
                Console.Write("Press any key to start over...press e to exit: ");
            } while (Console.ReadKey().Key != ConsoleKey.E);
        }


        public static void DisplayMenu()
        {
            Console.WriteLine("Welcome to Campus Cafeteria!");
            for (int i = 0; i < 3; i++)
            {
                switch (i)
                {
                    case 0:
                        Console.WriteLine("1---Breakfast: {0} meals remaining", Meal.GetRemainingMeals(i));
                        break;
                    case 1:
                        Console.WriteLine("2---Lunch: {0} meals remaining", Meal.GetRemainingMeals(i));
                        break;
                    case 2:
                        Console.WriteLine("3---Dinner: {0} meals remaining", Meal.GetRemainingMeals(i));
                        break;
                }
            }
            Console.WriteLine("4---Quit");
            Console.WriteLine();
            Console.Write("Enter a number from 1-3 to select meal type or 4 to quit: ");
        }

        public static string GetUserInput(string question)
        {
            Console.Write("{0}: ", question);
            return Console.ReadLine();
        }

        public static int ConvertStringToPositiveInt(string input)
        {
            int convertedNum = 0;

            int.TryParse(input, out convertedNum);

            if (convertedNum < 0)
            {
                convertedNum = 0;
            }

            return convertedNum;
        }

        public static int ConvertStringToInt(string input)
        {
            int convertedNum = 0;

            int.TryParse(input, out convertedNum);
            
            return convertedNum;
        }

        public static string GetPaymentChoice()
        {
            
            Console.WriteLine("\tPayment Choices:");
            Console.WriteLine("1. Use Meal Plan Credits");
            Console.WriteLine("2. Use Card");
            Console.WriteLine("3. View Plan Credits and Card Balance");
            Console.WriteLine("4. Cancel");

            return GetUserInput("Enter Choice");

        }
    }
}
