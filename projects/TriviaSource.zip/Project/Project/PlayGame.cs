﻿//Dylan Quintanar cis 345 12:00 project
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace TriviaNow
{
    public partial class PlayGame : Form
    {
        BindingList<Question> questionList = new BindingList<Question>();
        int questionNumber = 0;
        int selectedAnswer;
        int questionsLeft = 3;
        int questionsCorrect = 0;
        int[] questionIndexes = new int[3];

        public PlayGame()
        {
            InitializeComponent();
        }

        private void PlayGame_Load(object sender, EventArgs e)
        {
            FileStream file = new FileStream("questions.txt",
                FileMode.Open, FileAccess.Read);

            BinaryFormatter bf = new BinaryFormatter();
            questionList = (BindingList<Question>)bf.Deserialize(file);
            file.Close();

            //get three random questions
            Random rnd = new Random();
            questionIndexes[0] = rnd.Next(questionList.Count);
            do
            {
                questionIndexes[1] = rnd.Next(questionList.Count);
            } while (questionIndexes[1] == questionIndexes[0]);
            do
            {
                questionIndexes[2] = rnd.Next(questionList.Count);
            } while (questionIndexes[2] == questionIndexes[1] || questionIndexes[2] == questionIndexes[0]);

            DisplayQuestion();
        }

        private void answerButton_Click(object sender, EventArgs e)
        {
            if (choice1Radio.Checked == true) selectedAnswer = 0;
            if (choice2Radio.Checked == true) selectedAnswer = 1;
            if (choice3Radio.Checked == true) selectedAnswer = 2;
            if (choice4Radio.Checked == true) selectedAnswer = 3;

            if (selectedAnswer == questionList[questionIndexes[questionNumber]].CorrectChoice)
            {
                feedbackLabel.Visible = true;
                feedbackLabel.Text = "Correct!";
                questionsCorrect++;
                questionsCorrectLabel.Text = $"Questions Correct: {questionsCorrect}";
            }
            else
            {
                feedbackLabel.Visible = true;
                feedbackLabel.Text = questionList[questionIndexes[questionNumber]].Feedback;
            }

            questionsLeft--;
            questionsLeftLabel.Text = $"Questions Left: {questionsLeft}";
            questionNumber++;
            answerButton.Enabled = false;

            if (questionsLeft > 0) nextButton.Enabled = true;
        }

        public void DisplayQuestion()
        {
            questionLabel.Text = questionList[questionIndexes[questionNumber]].QuestionText;
            choice1Radio.Text = questionList[questionIndexes[questionNumber]].QuestionChoices[0];
            choice2Radio.Text = questionList[questionIndexes[questionNumber]].QuestionChoices[1];
            choice3Radio.Text = questionList[questionIndexes[questionNumber]].QuestionChoices[2];
            choice4Radio.Text = questionList[questionIndexes[questionNumber]].QuestionChoices[3];
        }

        private void nextButton_Click(object sender, EventArgs e)
        {
            DisplayQuestion();
            feedbackLabel.Visible = false;
            answerButton.Enabled = true;
            nextButton.Enabled = false;
        }
    }
}
