﻿namespace TriviaNow
{
    partial class AddQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.questionNameTextBox = new System.Windows.Forms.TextBox();
            this.choice1TextBox = new System.Windows.Forms.TextBox();
            this.choice2TextBox = new System.Windows.Forms.TextBox();
            this.choice3TextBox = new System.Windows.Forms.TextBox();
            this.choice4TextBox = new System.Windows.Forms.TextBox();
            this.feedbackTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.choicesGroupBox = new System.Windows.Forms.GroupBox();
            this.choice4RadioButton = new System.Windows.Forms.RadioButton();
            this.choice3RadioButton = new System.Windows.Forms.RadioButton();
            this.choice2RadioButton = new System.Windows.Forms.RadioButton();
            this.choice1RadioButton = new System.Windows.Forms.RadioButton();
            this.exitButton = new System.Windows.Forms.Button();
            this.choicesGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // questionNameTextBox
            // 
            this.questionNameTextBox.Location = new System.Drawing.Point(96, 12);
            this.questionNameTextBox.Name = "questionNameTextBox";
            this.questionNameTextBox.Size = new System.Drawing.Size(422, 38);
            this.questionNameTextBox.TabIndex = 0;
            // 
            // choice1TextBox
            // 
            this.choice1TextBox.Location = new System.Drawing.Point(96, 76);
            this.choice1TextBox.Name = "choice1TextBox";
            this.choice1TextBox.Size = new System.Drawing.Size(422, 38);
            this.choice1TextBox.TabIndex = 1;
            // 
            // choice2TextBox
            // 
            this.choice2TextBox.Location = new System.Drawing.Point(96, 152);
            this.choice2TextBox.Name = "choice2TextBox";
            this.choice2TextBox.Size = new System.Drawing.Size(422, 38);
            this.choice2TextBox.TabIndex = 2;
            // 
            // choice3TextBox
            // 
            this.choice3TextBox.Location = new System.Drawing.Point(96, 224);
            this.choice3TextBox.Name = "choice3TextBox";
            this.choice3TextBox.Size = new System.Drawing.Size(422, 38);
            this.choice3TextBox.TabIndex = 3;
            // 
            // choice4TextBox
            // 
            this.choice4TextBox.Location = new System.Drawing.Point(96, 294);
            this.choice4TextBox.Name = "choice4TextBox";
            this.choice4TextBox.Size = new System.Drawing.Size(422, 38);
            this.choice4TextBox.TabIndex = 4;
            // 
            // feedbackTextBox
            // 
            this.feedbackTextBox.Location = new System.Drawing.Point(96, 369);
            this.feedbackTextBox.Name = "feedbackTextBox";
            this.feedbackTextBox.Size = new System.Drawing.Size(422, 38);
            this.feedbackTextBox.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(592, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 32);
            this.label1.TabIndex = 7;
            this.label1.Text = "Enter a question";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(592, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(202, 32);
            this.label2.TabIndex = 8;
            this.label2.Text = "Enter Choice 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(592, 155);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(202, 32);
            this.label3.TabIndex = 9;
            this.label3.Text = "Enter Choice 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(592, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(202, 32);
            this.label4.TabIndex = 10;
            this.label4.Text = "Enter Choice 3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(592, 294);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(202, 32);
            this.label5.TabIndex = 11;
            this.label5.Text = "Enter Choice 4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(592, 366);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(277, 32);
            this.label6.TabIndex = 12;
            this.label6.Text = "Enter Feedback Text";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(592, 472);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(565, 32);
            this.label7.TabIndex = 13;
            this.label7.Text = "Choose which choice is solution to question";
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(548, 609);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(156, 52);
            this.submitButton.TabIndex = 14;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(745, 609);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(163, 52);
            this.clearButton.TabIndex = 15;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // choicesGroupBox
            // 
            this.choicesGroupBox.Controls.Add(this.choice4RadioButton);
            this.choicesGroupBox.Controls.Add(this.choice3RadioButton);
            this.choicesGroupBox.Controls.Add(this.choice2RadioButton);
            this.choicesGroupBox.Controls.Add(this.choice1RadioButton);
            this.choicesGroupBox.Location = new System.Drawing.Point(96, 423);
            this.choicesGroupBox.Name = "choicesGroupBox";
            this.choicesGroupBox.Size = new System.Drawing.Size(430, 171);
            this.choicesGroupBox.TabIndex = 16;
            this.choicesGroupBox.TabStop = false;
            // 
            // choice4RadioButton
            // 
            this.choice4RadioButton.AutoSize = true;
            this.choice4RadioButton.Location = new System.Drawing.Point(203, 108);
            this.choice4RadioButton.Name = "choice4RadioButton";
            this.choice4RadioButton.Size = new System.Drawing.Size(164, 36);
            this.choice4RadioButton.TabIndex = 3;
            this.choice4RadioButton.TabStop = true;
            this.choice4RadioButton.Tag = "3";
            this.choice4RadioButton.Text = "Choice 4";
            this.choice4RadioButton.UseVisualStyleBackColor = true;
            // 
            // choice3RadioButton
            // 
            this.choice3RadioButton.AutoSize = true;
            this.choice3RadioButton.Location = new System.Drawing.Point(6, 108);
            this.choice3RadioButton.Name = "choice3RadioButton";
            this.choice3RadioButton.Size = new System.Drawing.Size(164, 36);
            this.choice3RadioButton.TabIndex = 2;
            this.choice3RadioButton.TabStop = true;
            this.choice3RadioButton.Tag = "2";
            this.choice3RadioButton.Text = "Choice 3";
            this.choice3RadioButton.UseVisualStyleBackColor = true;
            // 
            // choice2RadioButton
            // 
            this.choice2RadioButton.AutoSize = true;
            this.choice2RadioButton.Location = new System.Drawing.Point(203, 37);
            this.choice2RadioButton.Name = "choice2RadioButton";
            this.choice2RadioButton.Size = new System.Drawing.Size(164, 36);
            this.choice2RadioButton.TabIndex = 1;
            this.choice2RadioButton.TabStop = true;
            this.choice2RadioButton.Tag = "1";
            this.choice2RadioButton.Text = "Choice 2";
            this.choice2RadioButton.UseVisualStyleBackColor = true;
            // 
            // choice1RadioButton
            // 
            this.choice1RadioButton.AutoSize = true;
            this.choice1RadioButton.Checked = true;
            this.choice1RadioButton.Location = new System.Drawing.Point(6, 37);
            this.choice1RadioButton.Name = "choice1RadioButton";
            this.choice1RadioButton.Size = new System.Drawing.Size(164, 36);
            this.choice1RadioButton.TabIndex = 0;
            this.choice1RadioButton.TabStop = true;
            this.choice1RadioButton.Tag = "0";
            this.choice1RadioButton.Text = "Choice 1";
            this.choice1RadioButton.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(951, 609);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(156, 52);
            this.exitButton.TabIndex = 17;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // AddQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1356, 912);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.choicesGroupBox);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.feedbackTextBox);
            this.Controls.Add(this.choice4TextBox);
            this.Controls.Add(this.choice3TextBox);
            this.Controls.Add(this.choice2TextBox);
            this.Controls.Add(this.choice1TextBox);
            this.Controls.Add(this.questionNameTextBox);
            this.Name = "AddQuestion";
            this.Text = "Add Question";
            this.choicesGroupBox.ResumeLayout(false);
            this.choicesGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox questionNameTextBox;
        private System.Windows.Forms.TextBox choice1TextBox;
        private System.Windows.Forms.TextBox choice2TextBox;
        private System.Windows.Forms.TextBox choice3TextBox;
        private System.Windows.Forms.TextBox choice4TextBox;
        private System.Windows.Forms.TextBox feedbackTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.GroupBox choicesGroupBox;
        private System.Windows.Forms.RadioButton choice4RadioButton;
        private System.Windows.Forms.RadioButton choice3RadioButton;
        private System.Windows.Forms.RadioButton choice2RadioButton;
        private System.Windows.Forms.RadioButton choice1RadioButton;
        private System.Windows.Forms.Button exitButton;
    }
}