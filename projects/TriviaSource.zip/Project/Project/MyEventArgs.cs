﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriviaNow
{
    class MyEventArgs : EventArgs
    {
        Question question;

        public MyEventArgs(Question question)
        {
            this.Question = question;
        }

        public Question Question
        {
            get
            {
                return question;
            }

            set
            {
                question = value;
            }
        }
    }
}
