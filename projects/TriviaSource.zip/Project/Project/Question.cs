﻿//Dylan Quintanar cis 345 12:00 project
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TriviaNow
{
    [Serializable]
    class Question
    {
        private string questionText = "";
        private string[] questionChoices = new string[4];
        private string feedback = "";
        private int correctChoice;

        public Question(string questionText, string[] questionChoices, string feedback, int correctChoice)
        {
            this.questionText = questionText;
            this.questionChoices = questionChoices;
            this.feedback = feedback;
            this.correctChoice = correctChoice;
        }

        public Question()
        {

        }

        public string QuestionText
        {
            get
            {
                return questionText;
            }

            set
            {
                questionText = value;
            }
        }

        public string[] QuestionChoices
        {
            get
            {
                return questionChoices;
            }

            set
            {
                questionChoices = value;
            }
        }

        public string Feedback
        {
            get
            {
                return feedback;
            }

            set
            {
                feedback = value;
            }
        }

        public int CorrectChoice
        {
            get
            {
                return correctChoice;
            }

            set
            {
                correctChoice = value;
            }
        }

        public override string ToString()
        {
            return QuestionText;
        }
    }
}
