﻿namespace TriviaNow
{
    partial class PlayGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.questionLabel = new System.Windows.Forms.Label();
            this.choicesGroupBox = new System.Windows.Forms.GroupBox();
            this.choice4Radio = new System.Windows.Forms.RadioButton();
            this.choice3Radio = new System.Windows.Forms.RadioButton();
            this.choice2Radio = new System.Windows.Forms.RadioButton();
            this.choice1Radio = new System.Windows.Forms.RadioButton();
            this.feedbackLabel = new System.Windows.Forms.Label();
            this.answerButton = new System.Windows.Forms.Button();
            this.questionsLeftLabel = new System.Windows.Forms.Label();
            this.questionsCorrectLabel = new System.Windows.Forms.Label();
            this.nextButton = new System.Windows.Forms.Button();
            this.choicesGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // questionLabel
            // 
            this.questionLabel.AutoSize = true;
            this.questionLabel.Location = new System.Drawing.Point(90, 97);
            this.questionLabel.Name = "questionLabel";
            this.questionLabel.Size = new System.Drawing.Size(130, 32);
            this.questionLabel.TabIndex = 0;
            this.questionLabel.Text = "Question";
            // 
            // choicesGroupBox
            // 
            this.choicesGroupBox.Controls.Add(this.choice4Radio);
            this.choicesGroupBox.Controls.Add(this.choice3Radio);
            this.choicesGroupBox.Controls.Add(this.choice2Radio);
            this.choicesGroupBox.Controls.Add(this.choice1Radio);
            this.choicesGroupBox.Location = new System.Drawing.Point(80, 173);
            this.choicesGroupBox.Name = "choicesGroupBox";
            this.choicesGroupBox.Size = new System.Drawing.Size(593, 186);
            this.choicesGroupBox.TabIndex = 1;
            this.choicesGroupBox.TabStop = false;
            // 
            // choice4Radio
            // 
            this.choice4Radio.AutoSize = true;
            this.choice4Radio.Location = new System.Drawing.Point(325, 94);
            this.choice4Radio.Name = "choice4Radio";
            this.choice4Radio.Size = new System.Drawing.Size(215, 36);
            this.choice4Radio.TabIndex = 3;
            this.choice4Radio.Text = "radioButton4";
            this.choice4Radio.UseVisualStyleBackColor = true;
            // 
            // choice3Radio
            // 
            this.choice3Radio.AutoSize = true;
            this.choice3Radio.Location = new System.Drawing.Point(16, 94);
            this.choice3Radio.Name = "choice3Radio";
            this.choice3Radio.Size = new System.Drawing.Size(215, 36);
            this.choice3Radio.TabIndex = 2;
            this.choice3Radio.Text = "radioButton3";
            this.choice3Radio.UseVisualStyleBackColor = true;
            // 
            // choice2Radio
            // 
            this.choice2Radio.AutoSize = true;
            this.choice2Radio.Location = new System.Drawing.Point(325, 24);
            this.choice2Radio.Name = "choice2Radio";
            this.choice2Radio.Size = new System.Drawing.Size(215, 36);
            this.choice2Radio.TabIndex = 1;
            this.choice2Radio.Text = "radioButton2";
            this.choice2Radio.UseVisualStyleBackColor = true;
            // 
            // choice1Radio
            // 
            this.choice1Radio.AutoSize = true;
            this.choice1Radio.Checked = true;
            this.choice1Radio.Location = new System.Drawing.Point(16, 24);
            this.choice1Radio.Name = "choice1Radio";
            this.choice1Radio.Size = new System.Drawing.Size(215, 36);
            this.choice1Radio.TabIndex = 0;
            this.choice1Radio.TabStop = true;
            this.choice1Radio.Text = "radioButton1";
            this.choice1Radio.UseVisualStyleBackColor = true;
            // 
            // feedbackLabel
            // 
            this.feedbackLabel.AutoSize = true;
            this.feedbackLabel.ForeColor = System.Drawing.Color.DarkRed;
            this.feedbackLabel.Location = new System.Drawing.Point(90, 388);
            this.feedbackLabel.Name = "feedbackLabel";
            this.feedbackLabel.Size = new System.Drawing.Size(131, 32);
            this.feedbackLabel.TabIndex = 2;
            this.feedbackLabel.Text = "feedback";
            this.feedbackLabel.Visible = false;
            // 
            // answerButton
            // 
            this.answerButton.Location = new System.Drawing.Point(176, 449);
            this.answerButton.Name = "answerButton";
            this.answerButton.Size = new System.Drawing.Size(144, 50);
            this.answerButton.TabIndex = 3;
            this.answerButton.Text = "Answer";
            this.answerButton.UseVisualStyleBackColor = true;
            this.answerButton.Click += new System.EventHandler(this.answerButton_Click);
            // 
            // questionsLeftLabel
            // 
            this.questionsLeftLabel.AutoSize = true;
            this.questionsLeftLabel.Location = new System.Drawing.Point(90, 34);
            this.questionsLeftLabel.Name = "questionsLeftLabel";
            this.questionsLeftLabel.Size = new System.Drawing.Size(230, 32);
            this.questionsLeftLabel.TabIndex = 4;
            this.questionsLeftLabel.Text = "Questions Left: 3";
            // 
            // questionsCorrectLabel
            // 
            this.questionsCorrectLabel.AutoSize = true;
            this.questionsCorrectLabel.Location = new System.Drawing.Point(399, 34);
            this.questionsCorrectLabel.Name = "questionsCorrectLabel";
            this.questionsCorrectLabel.Size = new System.Drawing.Size(274, 32);
            this.questionsCorrectLabel.TabIndex = 5;
            this.questionsCorrectLabel.Text = "Questions Correct: 0";
            // 
            // nextButton
            // 
            this.nextButton.Enabled = false;
            this.nextButton.Location = new System.Drawing.Point(366, 449);
            this.nextButton.Name = "nextButton";
            this.nextButton.Size = new System.Drawing.Size(207, 50);
            this.nextButton.TabIndex = 6;
            this.nextButton.Text = "Next Question";
            this.nextButton.UseVisualStyleBackColor = true;
            this.nextButton.Click += new System.EventHandler(this.nextButton_Click);
            // 
            // PlayGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(718, 584);
            this.Controls.Add(this.nextButton);
            this.Controls.Add(this.questionsCorrectLabel);
            this.Controls.Add(this.questionsLeftLabel);
            this.Controls.Add(this.answerButton);
            this.Controls.Add(this.feedbackLabel);
            this.Controls.Add(this.choicesGroupBox);
            this.Controls.Add(this.questionLabel);
            this.Name = "PlayGame";
            this.Text = "Play Game";
            this.Load += new System.EventHandler(this.PlayGame_Load);
            this.choicesGroupBox.ResumeLayout(false);
            this.choicesGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label questionLabel;
        private System.Windows.Forms.GroupBox choicesGroupBox;
        private System.Windows.Forms.RadioButton choice4Radio;
        private System.Windows.Forms.RadioButton choice3Radio;
        private System.Windows.Forms.RadioButton choice2Radio;
        private System.Windows.Forms.RadioButton choice1Radio;
        private System.Windows.Forms.Label feedbackLabel;
        private System.Windows.Forms.Button answerButton;
        private System.Windows.Forms.Label questionsLeftLabel;
        private System.Windows.Forms.Label questionsCorrectLabel;
        private System.Windows.Forms.Button nextButton;
    }
}