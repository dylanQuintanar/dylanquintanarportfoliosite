﻿//Dylan Quintanar CIS 345 12:00 project beta
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace TriviaNow
{
    public partial class Main : Form
    {
        BindingList<Question> questionList = new BindingList<Question>();
        AddQuestion addQuestionForm;
        EditQuestion editQuestionForm;
        PlayGame playGameForm;
        public static int questionListIndex;
        public static Object questionToEdit;

        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            questionListBox.DataSource = questionList;

            LoadQuestions();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddQuestionToList();
        }

        public void AddQuestionToList()
        {
            addQuestionForm = new AddQuestion();
            addQuestionForm.Show();

            addQuestionForm.NewQuestionAdded += new QuestionAdded(this.addQuestion_QuestionAdded);
        }

        public void LoadQuestions()
        {
            try
            {
                FileStream file = new FileStream("questions.txt",
                FileMode.Open, FileAccess.Read);

                BinaryFormatter bf = new BinaryFormatter();
                questionList = (BindingList<Question>)bf.Deserialize(file);
                questionListBox.DataSource = questionList;
                file.Close();
            }
            catch
            {

            }
        }

        private void addQuestion_QuestionAdded(object sender, EventArgs e)
        {
            MyEventArgs tmpArgs = (MyEventArgs)e;
            Question tmpQuestion = tmpArgs.Question;
            questionList.Add(tmpQuestion);
            questionListBox.DataSource = questionList;
        }

        public void SaveQuestions()
        {
            FileStream file = new FileStream("questions.txt",
                FileMode.Create, FileAccess.Write);

            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(file, questionList);
            file.Close();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteQuestions();
        }

        public void DeleteQuestions()
        {
            try
            {
                questionList.Remove(questionList[questionListBox.SelectedIndex]);
            }
            catch
            {

            }
            SaveQuestions();
        }

        private void Main_FormClosed(object sender, FormClosedEventArgs e)
        {
            SaveQuestions();
        }

        private void Main_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveQuestions();
        }

        private void startGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StartGame();
        }

        public void StartGame()
        {
            if(questionList.Count < 3)
            {
                MessageBox.Show("There must be at least 3 questions to start game");
            }
            else
            {
                playGameForm = new PlayGame();
                playGameForm.Show();
            }
        }

        private void playButton_Click(object sender, EventArgs e)
        {
            StartGame();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveQuestions();
            System.Environment.Exit(0);
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            AddQuestionToList();
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            EditQuestions();
        }

        public void EditQuestions()
        {
            try
            {
                questionListIndex = questionListBox.SelectedIndex;
                questionToEdit = questionList[questionListBox.SelectedIndex];

                editQuestionForm = new EditQuestion();
                editQuestionForm.Show();

                editQuestionForm.SaveQuestionEdit += new QuestionEdited(this.editQuestion_QuestionEdit);
            }
            catch
            {

            }
            
        }

        private void editQuestion_QuestionEdit(object sender, EventArgs e)
        {
            MyEventArgs tmpArgs = (MyEventArgs)e;
            Question tmpQuestion = tmpArgs.Question;
            questionList[questionListBox.SelectedIndex] = tmpQuestion;
            questionListBox.DataSource = questionList;
            SaveQuestions();
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditQuestions();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            DeleteQuestions();
        }

        private void search_Click(object sender, EventArgs e)
        {
            SearchQuestions();
        }

        public void SearchQuestions()
        {
            var searchResults =
                from q in questionList
                where q.QuestionText.Contains(searchTextBox.Text)
                select q;

            string results = "Results: \n";

            foreach (var qst in searchResults)
            {
                
                results += $"{qst.QuestionText} \n";
            }

            MessageBox.Show(results);

            searchTextBox.Clear();
        }

        private void seachToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchQuestions();
        }

        private void questionListBox_DoubleClick(object sender, EventArgs e)
        {
            EditQuestions();
        }
    }
}
