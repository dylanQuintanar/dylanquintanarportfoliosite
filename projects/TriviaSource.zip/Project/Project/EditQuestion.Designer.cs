﻿namespace TriviaNow
{
    partial class EditQuestion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.questionTextBox = new System.Windows.Forms.TextBox();
            this.feedbackTextBox = new System.Windows.Forms.TextBox();
            this.choice4TextBox = new System.Windows.Forms.TextBox();
            this.choice3TextBox = new System.Windows.Forms.TextBox();
            this.choice2TextBox = new System.Windows.Forms.TextBox();
            this.choice1TextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.questionButton = new System.Windows.Forms.Button();
            this.feedbackButton = new System.Windows.Forms.Button();
            this.choice4Button = new System.Windows.Forms.Button();
            this.choice3Button = new System.Windows.Forms.Button();
            this.choice2Button = new System.Windows.Forms.Button();
            this.choice1Button = new System.Windows.Forms.Button();
            this.choicesGroupBox = new System.Windows.Forms.GroupBox();
            this.choice4Radio = new System.Windows.Forms.RadioButton();
            this.choice2Radio = new System.Windows.Forms.RadioButton();
            this.choice1Radio = new System.Windows.Forms.RadioButton();
            this.choice3Radio = new System.Windows.Forms.RadioButton();
            this.chioceButton = new System.Windows.Forms.Button();
            this.saveButton = new System.Windows.Forms.Button();
            this.choicesGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // questionTextBox
            // 
            this.questionTextBox.Enabled = false;
            this.questionTextBox.Location = new System.Drawing.Point(249, 32);
            this.questionTextBox.Name = "questionTextBox";
            this.questionTextBox.Size = new System.Drawing.Size(571, 38);
            this.questionTextBox.TabIndex = 0;
            // 
            // feedbackTextBox
            // 
            this.feedbackTextBox.Enabled = false;
            this.feedbackTextBox.Location = new System.Drawing.Point(249, 347);
            this.feedbackTextBox.Name = "feedbackTextBox";
            this.feedbackTextBox.Size = new System.Drawing.Size(571, 38);
            this.feedbackTextBox.TabIndex = 2;
            // 
            // choice4TextBox
            // 
            this.choice4TextBox.Enabled = false;
            this.choice4TextBox.Location = new System.Drawing.Point(249, 287);
            this.choice4TextBox.Name = "choice4TextBox";
            this.choice4TextBox.Size = new System.Drawing.Size(571, 38);
            this.choice4TextBox.TabIndex = 3;
            // 
            // choice3TextBox
            // 
            this.choice3TextBox.Enabled = false;
            this.choice3TextBox.Location = new System.Drawing.Point(249, 223);
            this.choice3TextBox.Name = "choice3TextBox";
            this.choice3TextBox.Size = new System.Drawing.Size(571, 38);
            this.choice3TextBox.TabIndex = 4;
            // 
            // choice2TextBox
            // 
            this.choice2TextBox.Enabled = false;
            this.choice2TextBox.Location = new System.Drawing.Point(249, 161);
            this.choice2TextBox.Name = "choice2TextBox";
            this.choice2TextBox.Size = new System.Drawing.Size(571, 38);
            this.choice2TextBox.TabIndex = 5;
            // 
            // choice1TextBox
            // 
            this.choice1TextBox.Enabled = false;
            this.choice1TextBox.Location = new System.Drawing.Point(249, 96);
            this.choice1TextBox.Name = "choice1TextBox";
            this.choice1TextBox.Size = new System.Drawing.Size(571, 38);
            this.choice1TextBox.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 32);
            this.label1.TabIndex = 7;
            this.label1.Text = "Question";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 347);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(202, 32);
            this.label2.TabIndex = 8;
            this.label2.Text = "Feedback Text";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 285);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 32);
            this.label3.TabIndex = 9;
            this.label3.Text = "Choice 4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 223);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 32);
            this.label4.TabIndex = 10;
            this.label4.Text = "Choice 3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 161);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 32);
            this.label5.TabIndex = 11;
            this.label5.Text = "Choice 2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 99);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(127, 32);
            this.label6.TabIndex = 12;
            this.label6.Text = "Choice 1";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 444);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(203, 32);
            this.label7.TabIndex = 14;
            this.label7.Text = "Correct Choice";
            // 
            // questionButton
            // 
            this.questionButton.Location = new System.Drawing.Point(863, 32);
            this.questionButton.Name = "questionButton";
            this.questionButton.Size = new System.Drawing.Size(123, 56);
            this.questionButton.TabIndex = 15;
            this.questionButton.Text = "Edit";
            this.questionButton.UseVisualStyleBackColor = true;
            this.questionButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // feedbackButton
            // 
            this.feedbackButton.Location = new System.Drawing.Point(863, 347);
            this.feedbackButton.Name = "feedbackButton";
            this.feedbackButton.Size = new System.Drawing.Size(123, 56);
            this.feedbackButton.TabIndex = 16;
            this.feedbackButton.Text = "Edit";
            this.feedbackButton.UseVisualStyleBackColor = true;
            this.feedbackButton.Click += new System.EventHandler(this.feedbackButton_Click);
            // 
            // choice4Button
            // 
            this.choice4Button.Location = new System.Drawing.Point(863, 285);
            this.choice4Button.Name = "choice4Button";
            this.choice4Button.Size = new System.Drawing.Size(123, 56);
            this.choice4Button.TabIndex = 17;
            this.choice4Button.Text = "Edit";
            this.choice4Button.UseVisualStyleBackColor = true;
            this.choice4Button.Click += new System.EventHandler(this.choice4Button_Click);
            // 
            // choice3Button
            // 
            this.choice3Button.Location = new System.Drawing.Point(863, 223);
            this.choice3Button.Name = "choice3Button";
            this.choice3Button.Size = new System.Drawing.Size(123, 56);
            this.choice3Button.TabIndex = 18;
            this.choice3Button.Text = "Edit";
            this.choice3Button.UseVisualStyleBackColor = true;
            this.choice3Button.Click += new System.EventHandler(this.choice3Button_Click);
            // 
            // choice2Button
            // 
            this.choice2Button.Location = new System.Drawing.Point(863, 161);
            this.choice2Button.Name = "choice2Button";
            this.choice2Button.Size = new System.Drawing.Size(123, 56);
            this.choice2Button.TabIndex = 19;
            this.choice2Button.Text = "Edit";
            this.choice2Button.UseVisualStyleBackColor = true;
            this.choice2Button.Click += new System.EventHandler(this.choice2Button_Click);
            // 
            // choice1Button
            // 
            this.choice1Button.Location = new System.Drawing.Point(863, 96);
            this.choice1Button.Name = "choice1Button";
            this.choice1Button.Size = new System.Drawing.Size(123, 56);
            this.choice1Button.TabIndex = 20;
            this.choice1Button.Text = "Edit";
            this.choice1Button.UseVisualStyleBackColor = true;
            this.choice1Button.Click += new System.EventHandler(this.choice1Button_Click);
            // 
            // choicesGroupBox
            // 
            this.choicesGroupBox.Controls.Add(this.choice4Radio);
            this.choicesGroupBox.Controls.Add(this.choice2Radio);
            this.choicesGroupBox.Controls.Add(this.choice1Radio);
            this.choicesGroupBox.Controls.Add(this.choice3Radio);
            this.choicesGroupBox.Enabled = false;
            this.choicesGroupBox.Location = new System.Drawing.Point(249, 413);
            this.choicesGroupBox.Name = "choicesGroupBox";
            this.choicesGroupBox.Size = new System.Drawing.Size(530, 77);
            this.choicesGroupBox.TabIndex = 21;
            this.choicesGroupBox.TabStop = false;
            // 
            // choice4Radio
            // 
            this.choice4Radio.AutoSize = true;
            this.choice4Radio.Location = new System.Drawing.Point(287, 32);
            this.choice4Radio.Name = "choice4Radio";
            this.choice4Radio.Size = new System.Drawing.Size(68, 36);
            this.choice4Radio.TabIndex = 3;
            this.choice4Radio.TabStop = true;
            this.choice4Radio.Text = "4";
            this.choice4Radio.UseVisualStyleBackColor = true;
            // 
            // choice2Radio
            // 
            this.choice2Radio.AutoSize = true;
            this.choice2Radio.Location = new System.Drawing.Point(98, 31);
            this.choice2Radio.Name = "choice2Radio";
            this.choice2Radio.Size = new System.Drawing.Size(68, 36);
            this.choice2Radio.TabIndex = 1;
            this.choice2Radio.TabStop = true;
            this.choice2Radio.Text = "2";
            this.choice2Radio.UseVisualStyleBackColor = true;
            // 
            // choice1Radio
            // 
            this.choice1Radio.AutoSize = true;
            this.choice1Radio.Location = new System.Drawing.Point(6, 31);
            this.choice1Radio.Name = "choice1Radio";
            this.choice1Radio.Size = new System.Drawing.Size(68, 36);
            this.choice1Radio.TabIndex = 0;
            this.choice1Radio.TabStop = true;
            this.choice1Radio.Text = "1";
            this.choice1Radio.UseVisualStyleBackColor = true;
            // 
            // choice3Radio
            // 
            this.choice3Radio.AutoSize = true;
            this.choice3Radio.Location = new System.Drawing.Point(197, 32);
            this.choice3Radio.Name = "choice3Radio";
            this.choice3Radio.Size = new System.Drawing.Size(68, 36);
            this.choice3Radio.TabIndex = 2;
            this.choice3Radio.TabStop = true;
            this.choice3Radio.Text = "3";
            this.choice3Radio.UseVisualStyleBackColor = true;
            // 
            // chioceButton
            // 
            this.chioceButton.Location = new System.Drawing.Point(863, 435);
            this.chioceButton.Name = "chioceButton";
            this.chioceButton.Size = new System.Drawing.Size(123, 56);
            this.chioceButton.TabIndex = 22;
            this.chioceButton.Text = "Edit";
            this.chioceButton.UseVisualStyleBackColor = true;
            this.chioceButton.Click += new System.EventHandler(this.chioceButton_Click);
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(361, 513);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(345, 49);
            this.saveButton.TabIndex = 23;
            this.saveButton.Text = "Exit and Save Changes";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // EditQuestion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 633);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.chioceButton);
            this.Controls.Add(this.choicesGroupBox);
            this.Controls.Add(this.choice1Button);
            this.Controls.Add(this.choice2Button);
            this.Controls.Add(this.choice3Button);
            this.Controls.Add(this.choice4Button);
            this.Controls.Add(this.feedbackButton);
            this.Controls.Add(this.questionButton);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.choice1TextBox);
            this.Controls.Add(this.choice2TextBox);
            this.Controls.Add(this.choice3TextBox);
            this.Controls.Add(this.choice4TextBox);
            this.Controls.Add(this.feedbackTextBox);
            this.Controls.Add(this.questionTextBox);
            this.Name = "EditQuestion";
            this.Text = "Edit Question";
            this.Load += new System.EventHandler(this.EditQuestion_Load);
            this.choicesGroupBox.ResumeLayout(false);
            this.choicesGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox questionTextBox;
        private System.Windows.Forms.TextBox feedbackTextBox;
        private System.Windows.Forms.TextBox choice4TextBox;
        private System.Windows.Forms.TextBox choice3TextBox;
        private System.Windows.Forms.TextBox choice2TextBox;
        private System.Windows.Forms.TextBox choice1TextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button questionButton;
        private System.Windows.Forms.Button feedbackButton;
        private System.Windows.Forms.Button choice4Button;
        private System.Windows.Forms.Button choice3Button;
        private System.Windows.Forms.Button choice2Button;
        private System.Windows.Forms.Button choice1Button;
        private System.Windows.Forms.GroupBox choicesGroupBox;
        private System.Windows.Forms.RadioButton choice4Radio;
        private System.Windows.Forms.RadioButton choice3Radio;
        private System.Windows.Forms.RadioButton choice2Radio;
        private System.Windows.Forms.RadioButton choice1Radio;
        private System.Windows.Forms.Button chioceButton;
        private System.Windows.Forms.Button saveButton;
    }
}