﻿//Dylan Quintanar cis 345 12:00 project
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TriviaNow
{
    public delegate void QuestionEdited(object sender, EventArgs e);
    public partial class EditQuestion : Form
    {
        public event QuestionEdited SaveQuestionEdit;
        Question tmpQuestion;

        public EditQuestion()
        {
            InitializeComponent();
        }

        private void EditQuestion_Load(object sender, EventArgs e)
        {
            tmpQuestion = (Question)Main.questionToEdit;

            questionTextBox.Text = tmpQuestion.QuestionText;
            choice1TextBox.Text = tmpQuestion.QuestionChoices[0];
            choice2TextBox.Text = tmpQuestion.QuestionChoices[1];
            choice3TextBox.Text = tmpQuestion.QuestionChoices[2];
            choice4TextBox.Text = tmpQuestion.QuestionChoices[3];
            feedbackTextBox.Text = tmpQuestion.Feedback;
            if (tmpQuestion.CorrectChoice == 0) choice1Radio.Checked = true;
            if (tmpQuestion.CorrectChoice == 1) choice2Radio.Checked = true;
            if (tmpQuestion.CorrectChoice == 2) choice3Radio.Checked = true;
            if (tmpQuestion.CorrectChoice == 3) choice4Radio.Checked = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(questionButton.Text == "Edit")
            {
                questionTextBox.Enabled = true;
                questionButton.Text = "Save";
            }
            else
            {
                tmpQuestion.QuestionText = questionTextBox.Text;
                questionTextBox.Enabled = false;
                questionButton.Text = "Edit";
            }
        }

        private void choice1Button_Click(object sender, EventArgs e)
        {
            if (choice1Button.Text == "Edit")
            {
                choice1TextBox.Enabled = true;
                choice1Button.Text = "Save";
            }
            else
            {
                tmpQuestion.QuestionChoices[0] = choice1TextBox.Text;
                choice1TextBox.Enabled = false;
                choice1Button.Text = "Edit";
            }
        }

        private void choice2Button_Click(object sender, EventArgs e)
        {
            if (choice2Button.Text == "Edit")
            {
                choice2TextBox.Enabled = true;
                choice2Button.Text = "Save";
            }
            else
            {
                tmpQuestion.QuestionChoices[1] = choice2TextBox.Text;
                choice2TextBox.Enabled = false;
                choice2Button.Text = "Edit";
            }
        }

        private void choice3Button_Click(object sender, EventArgs e)
        {
            if (choice3Button.Text == "Edit")
            {
                choice3TextBox.Enabled = true;
                choice3Button.Text = "Save";
            }
            else
            {
                tmpQuestion.QuestionChoices[2] = choice3TextBox.Text;
                choice3TextBox.Enabled = false;
                choice3Button.Text = "Edit";
            }
        }

        private void choice4Button_Click(object sender, EventArgs e)
        {
            if (choice4Button.Text == "Edit")
            {
                choice4TextBox.Enabled = true;
                choice4Button.Text = "Save";
            }
            else
            {
                tmpQuestion.QuestionChoices[3] = choice4TextBox.Text;
                choice4TextBox.Enabled = false;
                choice4Button.Text = "Edit";
            }
        }

        private void feedbackButton_Click(object sender, EventArgs e)
        {
            if (feedbackButton.Text == "Edit")
            {
                feedbackTextBox.Enabled = true;
                feedbackButton.Text = "Save";
            }
            else
            {
                tmpQuestion.Feedback = feedbackTextBox.Text;
                feedbackTextBox.Enabled = false;
                feedbackButton.Text = "Edit";
            }
        }

        private void chioceButton_Click(object sender, EventArgs e)
        {
            if(chioceButton.Text == "Edit")
            {
                choicesGroupBox.Enabled = true;
                chioceButton.Text = "Save";
            }
            else
            {
                if (choice1Radio.Checked == true) tmpQuestion.CorrectChoice = 0;
                if (choice2Radio.Checked == true) tmpQuestion.CorrectChoice = 1;
                if (choice3Radio.Checked == true) tmpQuestion.CorrectChoice = 2;
                if (choice4Radio.Checked == true) tmpQuestion.CorrectChoice = 3;

                choicesGroupBox.Enabled = false;
                chioceButton.Text = "Edit";
            }
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            MyEventArgs tmpArgs = new MyEventArgs(tmpQuestion);

            if(SaveQuestionEdit != null) SaveQuestionEdit(this, tmpArgs);

            this.Close();
        }
    }
}
