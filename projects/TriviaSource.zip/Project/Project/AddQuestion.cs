﻿//Dylan Quintanar cis 345 12:00 project
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TriviaNow
{
    public delegate void QuestionAdded(object sender, EventArgs e);
    public partial class AddQuestion : Form
    {
        public event QuestionAdded NewQuestionAdded;

        public AddQuestion()
        {
            InitializeComponent();
        }


        public void Clear()
        {
            questionNameTextBox.Text = "";
            choice1TextBox.Text = "";
            choice2TextBox.Text = "";
            choice3TextBox.Text = "";
            choice4TextBox.Text = "";
            feedbackTextBox.Text = "";
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            //check if all text boxes have data
            if (questionNameTextBox.Text != "" &&
                choice1TextBox.Text != "" &&
                choice2TextBox.Text != "" &&
                choice3TextBox.Text != "" &&
                choice4TextBox.Text != "" &&
                feedbackTextBox.Text != "")
            {
                int correctChoice = 0;

                string[] choicesArray = {choice1TextBox.Text,
                                         choice2TextBox.Text,
                                         choice3TextBox.Text,
                                         choice4TextBox.Text};

                if (choice1RadioButton.Checked == true) correctChoice = 0;
                else if (choice2RadioButton.Checked == true) correctChoice = 1;
                else if (choice3RadioButton.Checked == true) correctChoice = 2;
                else if (choice4RadioButton.Checked == true) correctChoice = 3;

                Question tmpQuestion = new Question(questionNameTextBox.Text,
                                                    choicesArray,
                                                    feedbackTextBox.Text,
                                                    correctChoice);

                MyEventArgs tmpArgs = new MyEventArgs(tmpQuestion);

                if (NewQuestionAdded != null) NewQuestionAdded(this, tmpArgs);

                Clear();
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
